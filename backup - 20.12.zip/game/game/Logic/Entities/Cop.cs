﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Game.Logic.Entities
{
    /* TODO - class Cop : Person, Shooter
    {
        internal override bool blocksVision()
        {
            throw new NotImplementedException();
        }

        Weapon Shooter.weapon()
        {
            throw new NotImplementedException();
        }

        HitFunction Shooter.hitFunc()
        {
            throw new NotImplementedException();
        }

        Sight Shooter.sight()
        {
            throw new NotImplementedException();
        }
    }
     */
}
