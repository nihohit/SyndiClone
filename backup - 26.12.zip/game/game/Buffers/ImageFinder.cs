﻿using System;
using System.IO;
using System.Drawing;
using System.Text;
using System.Collections.Generic;

namespace Game.Buffers
{
    //Just some random stuff for the class
    enum BuildingStyle { BLUE, RED, GREEN, YELLOW }

    

    internal class Block
    {
        const int TILESIZE = 32;

        private readonly int x, y;

        Block(int _x, int _y)
        {
            this.x = _x / TILESIZE;
            this.y = _y / TILESIZE;
        }

        internal int Y
        {
            get { return y; }
        }

        internal int X
        {
            get { return x; }
        }

        internal bool EqualSize(Block check)
        {
            return ((this.X == check.X) && (this.y == check.Y));
        }
    }
    
    abstract class ImageFinder
    {
        abstract Image getSprite(Game.Logic.Entities.Entity);
    }

    class specImageFinder : ImageFinder
    {

        static Dictionary<Building, System.Drawing.Image> buildings = new Dictionary<Building, System.Drawing.Image>();
        static Dictionary<Tuple<Block, BuildingStyle>, System.Drawing.Image> templates = new Dictionary<Tuple<Block, BuildingStyle>, System.Drawing.Image>(new tupleEqualityComparer());
        private readonly Dictionary<Entity, SpriteLoop> spriteFinder;

        Image getSprite(Entity ent)
        {

            Image temp = this.spriteFinder[ent].getSprite();
            if (temp == null)
            {
                if (ent.Type == entityType.BUILDING)
                    temp = getBuildingImage((Building)ent);
                else
                {
                    //TODO
                }
            }
            return temp;
        }

        private Image getBuildingImage(Building building)
        {
            Image image = GetBuildingImage(build);
            /*magic code to convert from the Drawing image to SFML image)*/
            MemoryStream stream = new MemoryStream();
            image.Save(stream, ImageFormat.Png);
            build.Img = new SFML.Graphics.Image(stream);
        }

        internal static Image GetBuildingImage(Building building)
        {
            var temp = Tuple.Create(building.Dimensions, generateStyle(building.Loyalty));
            /*if (buildings.ContainsKey(building))
            {
                return buildings[building];
            }
            if (templates.ContainsKey(temp))
            {
                return templates[temp];
            }*/
            System.Drawing.Image image = generateBuildingImage(temp);
            buildings[building] = image;
            templates[temp] = image;
            return image;
        }

        private static System.Drawing.Image generateBuildingImage(Tuple<Block, BuildingStyle> temp)
        {
            int width = temp.Item1.X;
            int height = temp.Item1.Y;
            BuildingStyle style = temp.Item2;
            System.Drawing.Color basic = System.Drawing.Color.Gray;
            switch (style)
            {
                case BuildingStyle.YELLOW:
                    basic = System.Drawing.Color.Yellow;
                    break;
                case BuildingStyle.RED:
                    basic = System.Drawing.Color.Red;
                    break;
                case BuildingStyle.GREEN:
                    basic = System.Drawing.Color.Green;
                    break;
                case BuildingStyle.BLUE:
                    basic = System.Drawing.Color.Blue;
                    break;

            }
            Image img = new Bitmap(TILE_SIZE * width, TILE_SIZE * height);
            List<Image> images = new List<Image>();
            for (int i = 1; i <= width; i++)
            {
                for (int j = 1; j <= height; j++)
                {
                    images.Add(getBuildingTile(width, height, i, j, style));
                }
            }

            Graphics graphic = Graphics.FromImage(img);
            graphic.Clear(basic);
            int widthOffset = 0;
            int heightOffset = 0;
            int num = 1;

            foreach (Image image in images)
            {
                graphic.DrawImage(image, new Rectangle(widthOffset, heightOffset, image.Width, image.Height));
                num++;

                heightOffset += TILE_SIZE;
                if (heightOffset == img.Height)
                {
                    widthOffset += TILE_SIZE;
                    heightOffset = 0;
                }
            }

            return img;
        }

        private static Image getBuildingTile(int length, int width, int i, int j, BuildingStyle style)
        {
            //TODO - account for style
            Image img = null;
            int id = 0;
            if (i == 1)
            {
                id += 1;
            }
            if (i == length)
            {
                id += 9;
            }
            if (j == 1)
            {
                id += 10;
            }
            if (j == width)
            {
                id += 90;
            }
            switch (id)
            {
                case (0):
                    img = new Bitmap(city_images._0_buildingmiddle);
                    break;
                case (1):
                    img = new Bitmap(city_images._9_edge);
                    img.RotateFlip(RotateFlipType.Rotate180FlipNone);
                    break;
                case (9):
                    img = new Bitmap(city_images._9_edge);
                    break;
                case (10):
                    img = new Bitmap(city_images._9_edge);
                    img.RotateFlip(RotateFlipType.Rotate270FlipNone);
                    break;
                case (90):
                    img = new Bitmap(city_images._9_edge);
                    img.RotateFlip(RotateFlipType.Rotate90FlipNone);
                    break;
                case (11):
                    img = new Bitmap(city_images._9_corner);
                    img.RotateFlip(RotateFlipType.RotateNoneFlipX);
                    break;
                case (91):
                    img = new Bitmap(city_images._9_corner);
                    img.RotateFlip(RotateFlipType.Rotate90FlipX);
                    break;
                case (19):
                    img = new Bitmap(city_images._9_corner);
                    break;
                case (99):
                    img = new Bitmap(city_images._9_corner);
                    img.RotateFlip(RotateFlipType.Rotate90FlipNone);
                    break;
            }

            //TODO - needs testing
            return img;
        }

        private static BuildingStyle generateStyle(Corporate corp)
        {
            //TODO - missing function
            int num = corp.Id % 4;
            return (BuildingStyle)num;
        }
    }

    //TODO - needs testing
    class tupleEqualityComparer : IEqualityComparer<Tuple<Block, BuildingStyle>>
    {

        public bool Equals(Tuple<Block, BuildingStyle> first, Tuple<Block, BuildingStyle> second)
        {
            return (first.Item1.EqualSize(second.Item1) && first.Item2 == second.Item2);
        }


        public int GetHashCode(Tuple<Block, BuildingStyle> item)
        {
            int hCode = item.Item1.X * item.Item1.Y * item.Item2.GetHashCode();
            return hCode.GetHashCode();
        }

    }
}
